# LigInt reference suite — starter v0.1

This is **NOT** a validated gold standard. It is a reproducible starting inventory extracted from the PDB fixtures distributed with LigInt 0.3.0.

- `structures_manifest.csv` records the available fixtures and hetero-residue candidates.
- `candidate_contacts.csv` contains short heavy-atom contacts to protein or metal atoms, computed geometrically (<=4.2 Å). Each record is **UNREVIEWED**, has **no positive/negative label**, and must NOT be used for precision/recall.
- The contact list is deliberately restricted to a maximum of 150 shortest candidates per ligand and excludes water as partner, so it is not an exhaustive contact annotation.
- No biological relevance or correctness of a candidate ligand has been assumed.

## Next steps to create a genuine reference suite
1. Resolve biological ligand and interacting site for each structure; preserve chain IDs, insertion codes, alternate locations, occupancy, and the CCD chemical definition.
2. Run PLIP and Arpeggio independently (record tool versions and parameters); standardize atom identifiers, including any atom-name remapping.
3. Stratify candidates by interaction class, including water bridges and ring-/group-based interactions (which this atom-contact inventory cannot represent).
4. Have qualified reviewers curate **positive**, **negative** and **uncertain** labels, with geometry, chemistry, protonation assumptions and evidence for each decision.
5. Freeze validation set by structural family to prevent leakage. Only curated cases should contribute to performance metrics.

## Example LigInt CLI
```
ligint tests/data/1AZM.pdb --csv > ligint_1AZM.csv
```

Sources: local LigInt v0.3.0 test fixtures supplied with user archive. Review primary PDB/mmCIF and authoritative CCD before external publication.
