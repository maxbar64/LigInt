# ligint

Non-covalent **ligand-protein interactions** from a PDB file: hydrogen bonds, salt bridges, hydrophobic contacts,
π-stacking, cation-π, halogen bonds, metal coordination and water bridges, plus clashes and repulsions. The project
contains:

| Component | What it is |
|---|---|
| `ligint_core` | C++17 library with no dependencies (API in `include/ligint/ligint.hpp`) |
| `ligint` | command-line program (readable table or CSV) |
| `ligint-gui` | Qt graphical interface with a 3D view of the interactions, tables and filters |
| `tests/` | C++ tests, Python suite, GUI smoke test, comparison with PLIP |

![GUI on 1HSG (indinavir)](docs/img/gui-1HSG-window.png)

## Building

Requirements: **CMake ≥ 3.16**, a **C++17** compiler; for the GUI **Qt 6** (or Qt 5) with Widgets and Concurrent.
If Qt is not found, CMake warns and builds only the library and the command line.

```
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure      # with QT_QPA_PLATFORM=offscreen if there is no display
cmake --install build --prefix /installation/path
```

With CMake ≥ 3.21 you can use the presets: `cmake --preset release && cmake --build --preset release`
(other presets: `debug`, `cli-only`, `sanitize`).

| CMake option | Default | Meaning |
|---|---|---|
| `LIGINT_BUILD_CLI` | ON | `ligint` executable |
| `LIGINT_BUILD_GUI` | ON | `ligint-gui` (requires Qt; if missing, a warning and the build continues) |
| `LIGINT_BUILD_TESTS` | ON | tests registered in CTest |
| `LIGINT_SANITIZE` | OFF | AddressSanitizer + UBSan (GCC/Clang; better without the GUI) |
| `LIGINT_WARNINGS_AS_ERRORS` | OFF | compiler warnings as errors |
| `LIGINT_BUILD_SCREENSHOT_TOOL` | OFF | `ligint-screenshot`, for the documentation images |

## Usage

### Command line

```
ligint structure.pdb                       list the ligands (HETATM) present, with the number of copies
ligint structure.pdb ATP                   analyze all ATP ligands
ligint structure.pdb ATP A 501             only chain A, residue 501
ligint structure.pdb ATP --csv             CSV output (service information goes to stderr)
ligint structure.pdb LIG --sdf lig.sdf     chemical annotation from SDF (also --mol2)
ligint structure.pdb LIG --plip-like       preset for the comparison with PLIP
ligint --help                              thresholds and default values
```

Options: `--csv`, `--no-water`, `--no-merge`, `--plip-like`, `--sdf F`, `--mol2 F`, `--metal-donors`,
`--backbone-hyd`, `--hb-long X`, `--salt-centroid X`, `--version` and all the thresholds (`--hb-max`, `--salt-max`,
`--hyd-max`, ...; see `--help`). Unknown options, non-numeric thresholds or missing files end with an error
(exit code 1); thresholds above 6 Å for the grid searches are limited with a warning.

The CSV columns are `ligand,type,favorable,ligand_atom,protein_atom,distance,notes`; the interaction types are
listed below and are available as constants in `ligint::type`.

### Graphical interface

```
ligint-gui [structure.pdb]
```

Open a PDB (menu, drag and drop or argument), choose the ligand, adjust options and thresholds, press **Analyze**.
The 3D view (drag: rotate; right or middle button: pan; wheel: zoom; double click: reset) shows the ligand, the
residues in contact, ions and waters, with the interactions colored by type, distances, labels and a legend.
Selecting a row of the table highlights the interaction in the view. You can filter the types, add SDF/MOL2
templates, export the interactions to CSV and save the image as PNG. The analysis runs in a separate thread.

![3D view on 4IKF (integrase inhibitor, Mg, DNA)](docs/img/gui-4IKF-viewer.png)

### As a library

```cpp
#include <ligint/ligint.hpp>

ligint::Options opt;
opt.ligName = "ATP";
opt.params.applyPlipLike();                    // optional
ligint::Result r = ligint::analyzeFile("1ATP.pdb", opt);
for (const auto& lig : r.ligands)
    for (const auto& h : lig.hits)             // type, atoms, distance, coordinates for the graphics...
        std::cout << h.type << " " << h.ligandAtom << " " << h.proteinAtom << " " << h.distance << "\n";
```

The library prints nothing: warnings and information are in the `Result`. `printText` and `printCsv` reproduce the
command-line output. In another CMake project, after `cmake --install`:

```cmake
find_package(ligint REQUIRED)
target_link_libraries(my_program PRIVATE ligint::core)
```

## What it recognizes (default thresholds)

| Type | Criterion |
|---|---|
| Hydrogen bond | D···A 2.2–3.5 Å, compatible donor and acceptor; with known H: D–H···A ≥ 120° and H···A ≤ 2.7 Å, otherwise antecedent angle ≥ 90° (amines with three substituents: N–H axis within 50°) |
| Salt bridge | opposite charges, atoms ≤ 4.0 Å; with an H-bond on the same pair a single row "also hydrogen bond" |
| Electrostatic repulsion | like charges ≤ 4.5 Å |
| Hydrophobic contact | apolar C–C at 3.3–4.0 Å (carbons not bonded to N/O/P) |
| pi-stacking | centroids ≤ 5.5 Å; parallel (normals ≤ 30°, planes 3.0–4.5 Å apart, offset ≤ 3.5 Å) or T-shaped (≥ 60°, offset ≤ 2.0 Å) |
| Cation-pi | cation–centroid ≤ 6.0 Å, within 30° of the ring axis |
| Halogen bond | Cl/Br/I···N/O/S ≤ 3.5 Å, C–X···A angle ≥ 140° (fluorine is not considered) |
| Metal coordination | O/N with a lone pair or S within the per-element limit (Mg 2.5; Zn 2.6; Ca 2.8; ...) |
| Water bridge | water 2.2–3.5 Å from both ligand and protein, ligand–O–protein angle 75–140°, without direct contact |
| Steric clash | distance < sum of the van der Waals radii − 0.5 Å |
| Possible covalent bond | distance < 2.0 Å |

### Chemical assumptions

Crystallographic PDB files have no hydrogens, so the ligand chemistry is inferred from the geometry:

- **Physiological pH:** carboxylates, phosphates and sulfonates (two terminal O on the same atom) are anionic;
  aliphatic amines with only sp3 substituents, and amidines and guanidines not in a ring, are cationic.
- **Amides:** an N bonded to a carbonyl C is not an acceptor. A ring N with a lone pair is an acceptor.
- **Metals:** O/N coordinated to a metal are considered deprotonated (not donors) unless `--metal-donors`;
  His and other N bound to a metal make no H-bonds.
- **Histidine:** donor and acceptor, never charged.
- **Protein:** DNA/RNA are partners (phosphates, bases, stacking); if the PDB contains the protein hydrogens they are used.
- **Only the first model is read;** for each residue the first alternative conformation encountered is kept.
- **Multi-residue ligands** (disaccharides, glycans, dipeptides) covalently linked are a single ligand
  (as in PLIP); `--no-merge` keeps them separate.

### SDF and MOL2

`--sdf` / `--mol2` provide bond orders, explicit hydrogens and formal charges. The PDB ligand is matched to the
template **by coordinates** (tolerance 0.6 Å, same number of heavy atoms): the file must have the same coordinates as
the PDB. With hydrogens in the template, donors/acceptors and D–H···A angles are real; without H, or if the matching
fails, the geometric heuristics are used (the program says so). SDF V3000 is not supported.

### Presets and options for the comparison with PLIP

- `--hb-long 4.1`: H-bonds with D···A up to 4.1 Å only if the H (real or ideal) can point to the acceptor.
- `--salt-centroid 5.5`: salt bridges between the centroids of the charged groups (one contact per group).
- `--plip-like` = `--hb-long 4.1 --salt-centroid 5.5 --hal-max 4.0`; explicit options take precedence.

They are off by default: `--hb-long` was confirmed on data not used for the tuning, `--salt-centroid` has a small and
uncertain effect.

## Verification

```
ctest --test-dir build --output-on-failure           core_unit + python_suite + gui_smoke
python3 tests/run_tests.py [--bin build/src/ligint] [--sanitize]     67 Python tests (chemical rules, SDF/MOL2,
                                                     parsing, malformed input, real complexes in tests/data)
python3 tests/compare_plip.py *.pdb                  ligint against PLIP (pip install plip openbabel-wheel)
python3 tests/benchmark.py folder/ --groups g.txt    full pipeline with report and CSV of the disagreements
```

**Agreement with PLIP** (one copy per ligand and PDB; sensitivity = PLIP interactions found; precision =
ligint interactions also present in PLIP; 95% intervals by bootstrap over the structures):

| Group | Sites | Sensitivity | Precision |
|---|---:|---|---|
| A, B (used for the corrections) | 84 | 81% [77–84] | 75% [71–78] |
| C (blind, examined afterwards) | 83 | 77% [73–80] | 70% [66–73] |
| D (blind), default | 47 structures | 75% [70–80] | 70% [66–74] |
| D, `--plip-like` | 47 structures | 79% [74–84] | 70% [65–74] |

Details, method and limits in [`docs/BENCHMARK.md`](docs/BENCHMARK.md); reports and CSV of the disagreements in `docs/benchmark/`.
**PLIP is not the truth:** many disagreements are conventions (see below), and the comparison does not replace a
validation with experimental data.

## Known limits and differences from PLIP

- PLIP counts **fluorine** halogen bonds too; ligint does not.
- PLIP treats **histidine as positively charged** (about a third of the missing salt bridges); ligint does not.
- PLIP counts hydrophobic contacts of carbons of polar residues and of heme; ligint limits them to hydrophobic residues.
- **Water bridges:** PLIP applies its own filters (a donor already in an H-bond cannot form a bridge, at most two
  bridges per donor water); ligint does not and reports many more bridges (precision ≈ 40%).
- PLIP does not analyze nucleic acids as partners; ligint does (not validated against a reference).
- Not covered: SDF V3000, NMR structures with several models, pH values other than physiological, covalent bonds with the
  protein (only flagged as "possible covalent bond"), real SDF/MOL2 files from docking (only the 1EFY SDF and a synthetic
  MOL2 were tried).

## Test status

Verified: Linux, GCC 13 and Clang 18 with `-Wall -Wextra -Werror`, Qt 6.4 with the offscreen platform (smoke test and
screenshots), build with ASan+UBSan, installation and use as a CMake package. **Not verified:** macOS and Windows, Qt 5
(the code avoids Qt6-only APIs, but it was not compiled). The workflows in `.github/workflows/` **have never been
run**: the commands are the ones tried here locally on Linux (including `-Werror`, clang and sanitizers), but the first
run on GitHub may need adjustments. The GUI was tried in offscreen mode: interactive use with mouse and dialog boxes
was not tried by hand.

## Layout

```
include/ligint/ligint.hpp   public API
src/core/                   library: analysis.cpp, chemistry.cpp, templates.cpp, report.cpp, internal.hpp
src/cli/main.cpp            command line
gui/                        Qt GUI (MainWindow, ViewerWidget, HitsModel, Style) and screenshot tool
tests/                      unit/ (C++), gui/ (smoke test), run_tests.py, compare_plip.py, benchmark.py, data/ (test PDB files)
docs/                       ARCHITECTURE.md, BENCHMARK.md, benchmark/ (reports), img/
cmake/                      CMake package configuration files
```

Other documents: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md), [`CONTRIBUTING.md`](CONTRIBUTING.md), [`CHANGELOG.md`](CHANGELOG.md).

## License

MIT, see [`LICENSE`](LICENSE) (the copyright holder is a placeholder: change it before publishing). The PDB files in
`tests/data/` are Protein Data Bank data (public domain, CC0); `1efy.sdf` was generated with Protoss
(ProteinsPlus) from PDB entry 1EFY.
